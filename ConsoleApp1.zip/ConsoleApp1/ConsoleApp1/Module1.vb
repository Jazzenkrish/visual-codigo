﻿Module Module1
    ' Declaración del delegado para la función objetivo F(x)
    Public Delegate Function FuncionObjetivo(ByVal x As Double) As Double

    ' Define la función Secante que toma como parámetros una función objetivo, dos estimaciones iniciales X0 y X1,
    ' un criterio de tolerancia EPS y un número máximo de iteraciones MAXIT.
    Public Function Secante(ByVal F As FuncionObjetivo, ByVal X0 As Double, ByVal X1 As Double, ByVal EPS As Double, ByVal MAXIT As Integer) As Double
        Dim I As Integer = 1  ' Inicializa el contador de iteraciones

        Dim X As Double  ' Variable para almacenar la actual estimación de la raíz

        ' Bucle que se ejecuta hasta alcanzar el número máximo de iteraciones permitidas
        Do While I <= MAXIT
            ' Calcula el denominador de la fórmula de la secante
            Dim denom As Double = F(X1) - F(X0)
            ' Verifica que el denominador no sea cero para evitar división por cero
            If denom = 0 Then
                Throw New Exception("División por cero en el método de la secante.")
            End If

            ' Aplica la fórmula de la secante para encontrar la nueva aproximación de la raíz
            X = X0 - (X1 - X0) * F(X0) / denom

            ' Comprueba si la diferencia absoluta entre la última aproximación y la nueva es menor que la tolerancia EPS
            If Math.Abs(X - X1) < EPS Then
                Return X  ' Si es así, retorna la nueva aproximación como la raíz
            End If

            ' Comprueba si el valor absoluto de F evaluado en la nueva aproximación es menor que EPS
            If Math.Abs(F(X)) < EPS Then
                Return X  ' Si es así, retorna la nueva aproximación como la raíz
            End If

            ' Actualiza los valores de X0 y X1 para la siguiente iteración
            X0 = X1
            X1 = X
            I += 1  ' Incrementa el contador de iteraciones
        Loop

        ' Si se alcanza este punto, significa que el método no encontró una raíz en el número máximo de iteraciones
        Throw New Exception("El método no converge a una raíz.")
    End Function

    ' Esta función es un ejemplo de una función objetivo. En este caso, se está utilizando una parábola con raíces en x = -2 y x = 2.
    Public Function F(ByVal x As Double) As Double
        Return x * x - 4  ' Devuelve el valor de x al cuadrado menos 4
    End Function

    ' El procedimiento principal que se ejecuta cuando inicia el programa.
    Sub Main()
        Try
            ' Intenta encontrar la raíz de la función F usando el método de la secante con los parámetros proporcionados
            Dim Root As Double = Secante(AddressOf F, 1, 2, 0.0001, 100)
            ' Si se encuentra una raíz, imprime el resultado en la consola
            Console.WriteLine("La raíz encontrada es: " & Root.ToString())
        Catch ex As Exception
            ' Si hay una excepción, imprime el mensaje de error en la consola
            Console.WriteLine(ex.Message)
        Finally
            ' Imprime un mensaje en la consola y espera a que el usuario presione una tecla antes de cerrar el programa
            Console.WriteLine("Presione cualquier tecla para finalizar...")
            Console.ReadLine()
        End Try
    End Sub



End Module
