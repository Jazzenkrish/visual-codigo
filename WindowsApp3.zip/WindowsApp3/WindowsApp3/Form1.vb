﻿Public Class Form1
    Private puntos(,) As Double
    Private n As Integer ' Número de puntos

    ' Se declaran las variables que antes no estaban declaradas
    Private sumaE As Double
    Private sumaW As Double
    Private sumaN As Double
    Private sumaS As Double
    Private ErrorX As Double
    Private ErrorY As Double
    Private Kx As Double
    Private Ky As Double
    Private ProyNat(,) As Double ' Debes definir el tamaño de esta matriz
    Private Correc(,) As Double ' Debes definir el tamaño de esta matriz
    Private ProyCom(,) As Double ' Debes definir el tamaño de esta matriz
    Private Signo() As Integer ' Debes definir el tamaño de este array
    Private AngInt(,) As Double ' Debes definir el tamaño de esta matriz
    Private Azimut() As Double ' Debes definir el tamaño de este array
    Private Dist() As Double ' Debes definir el tamaño de este array
    Private AzG As Double
    Private Azm As Double
    Private AzS As Double
    Private EjeX() As String ' Corrección: Declarar el array EjeX
    Private EjeY() As String ' Corrección: Declarar el array EjeY

    Public Sub New()
        ' Esta llamada es requerida por el diseñador.
        InitializeComponent()
        ' Agrega cualquier inicialización después de la llamada a InitializeComponent().
        ' Asegúrate de que pic no sea nulo y se haya añadido al formulario aquí si no se ha hecho en el diseñador.
    End Sub

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        puntos = New Double(,) {
            {40.2847, 99.0785}, {22.2608, 101.6127},
            {8.4658, 77.8178}, {1.0, 59.7938}, {1.0, 40.2847},
            {8.4658, 22.2608}, {22.2608, 8.4658},
            {40.2847, 1.0}, {59.7938, 1.0}, {77.8178, 8.4658},
            {91.6127, 22.2608}, {99.0785, 40.2847},
            {99.0785, 59.7938}, {91.6127, 77.8178},
            {77.8178, 91.6127}, {59.7938, 99.0785},
            {40.2847, 99.0785}
        }
        n = puntos.GetLength(0) - 1
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dibujar.Click
        n = 15
        Call GRAFICO()
    End Sub
    Private Sub GRAFICO()
        ' Define el lápiz para dibujar y los márgenes solo una vez
        Dim lapiz As New Pen(Color.Black)
        Dim margen As Integer = 20

        ' Calcula las coordenadas del mundo real y de la pantalla
        Dim xwl As Double = xMin()
        Dim xwr As Double = xMax()
        Dim ywb As Double = yMin()
        Dim ywt As Double = yMax()

        Dim xvl As Integer = margen
        Dim xvr As Integer = pic.ClientSize.Width - margen
        Dim yvb As Integer = margen
        Dim yvt As Integer = pic.ClientSize.Height - margen

        Dim a As Double = (xvr - xvl) / (xwr - xwl)
        Dim c As Double = (yvt - yvb) / (ywt - ywb)
        Dim b As Double = xvl - a * xwl
        Dim d As Double = yvb - c * ywb

        ' Transforma y escala las coordenadas del mundo real a coordenadas de pantalla
        Dim iCoordPant(n, 1) As Integer
        For i As Integer = 0 To n
            iCoordPant(i, 0) = CInt(a * puntos(i, 0) + b)
            iCoordPant(i, 1) = CInt(c * puntos(i, 1) + d)
        Next

        ' Utiliza Using para asegurar que el objeto Graphics se desecha adecuadamente
        Using dibujo As Graphics = pic.CreateGraphics()
            ' Configura el sistema de coordenadas para el dibujo
            dibujo.TranslateTransform(0, pic.ClientSize.Height)
            dibujo.ScaleTransform(1, -1)

            ' Dibuja las líneas entre los puntos
            For i As Integer = 0 To n - 1
                dibujo.DrawLine(lapiz, iCoordPant(i, 0), iCoordPant(i, 1), iCoordPant(i + 1, 0), iCoordPant(i + 1, 1))
            Next
        End Using ' El objeto Graphics se desecha automáticamente al salir del bloque Using

        ' Limpia los recursos del lápiz
        lapiz.Dispose()
    End Sub

    Public Function xMin() As Double
        Dim min As Double
        min = puntos(0, 0)
        For i = 1 To n
            If puntos(i, 0) < min Then
                min = puntos(i, 0)
            End If
        Next
        Return min
    End Function
    Public Function yMin() As Double
        Dim i As Integer
        Dim min As Double
        min = puntos(0, 1)
        For i = 1 To n
            If puntos(i, 1) < min Then
                min = puntos(i, 1)
            End If
        Next
        Return min
    End Function
    Public Function xMax() As Double
        Dim i As Integer
        Dim max As Double
        max = puntos(0, 0)
        For i = 1 To n
            If puntos(i, 0) > max Then
                max = puntos(i, 0)
            End If
        Next
        Return max
    End Function
    Public Function yMax() As Double
        Dim i As Integer
        Dim max As Double
        max = puntos(0, 1)
        For i = 1 To n
            If puntos(i, 1) > max Then
                max = puntos(i, 1)
            End If
        Next
        Return max


    End Function
    Private Sub calculos()


        'determinación de las sumas de las proyecciones naturales 
        sumaE = 0
        sumaW = 0
        sumaN = 0
        sumaS = 0
        For i = 1 To n
            sumaE += ProyNat(i, 1)
            sumaW += ProyNat(i, 2)
            sumaN += ProyNat(i, 3)
            sumaS += ProyNat(i, 4)
        Next
        ErrorX = Math.Abs(sumaE - sumaW)
        ErrorY = Math.Abs(sumaN - sumaS)
        Kx = ErrorX / (sumaE + sumaW)
        Ky = ErrorY / (sumaN + sumaS)
        'calculo de las correcciones 

        For i = 1 To n
            If EjeX(i) = "E" Then
                Correc(i, 1) = ProyNat(i, 1) * Kx
            Else
                Correc(i, 1) = ProyNat(i, 2) * Kx
            End If
            If EjeY(i) = "N" Then
                Correc(i, 2) = ProyNat(i, 3) * Ky
            Else
                Correc(i, 2) = ProyNat(i, 4) * Ky
            End If
        Next

        Dim Signo(4) As Integer
        If sumaE > sumaW Then
            Signo(1) = -1
            Signo(2) = 1
        Else
            Signo(1) = 1
            Signo(2) = -1
        End If
        If sumaN > sumaS Then
            Signo(3) = -1
            Signo(4) = 1
        Else
            Signo(3) = 1
            Signo(4) = -1
        End If
        For i = 1 To n
            '
            If EjeX(i) = "E" Then
                ProyCom(i, 1) = ProyNat(i, 1) + Correc(i, 1) * Signo(1)
                ProyCom(i, 2) = 0
            Else
                ProyCom(i, 1) = 0
                ProyCom(i, 2) = ProyNat(i, 2) + Correc(i, 1) * Signo(2)
            End If
            '
            If EjeY(i) = "N" Then
                ProyCom(i, 3) = ProyNat(i, 3) + Correc(i, 2) * Signo(3)
                ProyCom(i, 4) = 0
            Else
                ProyCom(i, 3) = 0
                ProyCom(i, 4) = ProyNat(i, 4) + Correc(i, 2) * Signo(4)
            End If
        Next
        DataGridView1.ColumnCount = 7 'define la cantidad
        DataGridView1.RowCount = n + 1 'define la cantidad 

        'colocar los titulos
        DataGridView1.Columns(0).Name = "grados"
        DataGridView1.Columns(1).Name = "minutos"
        DataGridView1.Columns(2).Name = "segundos"
        DataGridView1.Columns(3).Name = "azimuts"

        'mostrar la información 
        For i = 1 To n
            DataGridView1.Item(0, i).Value = CStr(AngInt(i, 1))
            DataGridView1.Item(1, i).Value = CStr(AngInt(i, 2))
            DataGridView1.Item(2, i).Value = CStr(AngInt(i, 3))
            DataGridView1.Item(3, i).Value = CStr(Azimut(i))
        Next

        'entrada del azimut inicial
        AzG = Val(InputBox("azimut en grados"))
        Azm = Val(InputBox("azimut en minutos"))
        AzS = Val(InputBox("azimut en segundos"))

        'entrada de las distancias 
        For i = 1 To n
            Dist(i) = Val(InputBox("distancias"))
        Next

        'entrada de las coordenadas iniciales 
        puntos(0, 0) = Val(InputBox("coordenadas X"))

    End Sub
    'proceso
    'conversion de los angulos de grados sexagecimales a grados
End Class
